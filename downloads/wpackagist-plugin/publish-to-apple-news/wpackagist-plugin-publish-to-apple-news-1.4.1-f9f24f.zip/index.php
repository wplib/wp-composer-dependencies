<?php
/**
 * Publish to Apple News: Index dummy file
 *
 * @package Apple_News
 */

// Silence is golden.
