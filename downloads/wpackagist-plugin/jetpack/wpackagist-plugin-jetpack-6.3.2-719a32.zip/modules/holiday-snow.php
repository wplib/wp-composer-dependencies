<?php
/**
 * Deprecated. No longer included in Jetpack.
 *
 * @package Jetpack
 */
