=== Categories to Tags Converter ===
Contributors: wordpressdotorg
Donate link: 
Tags: importer, categories and tags converter
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 0.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Convert existing categories to tags or tags to categories, selectively.

== Description ==

Convert existing categories to tags or tags to categories, selectively.

== Installation ==

1. Upload the `wpcat2tag-importer` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to the Tools -> Import screen, Click on Categories and Tags Converter

== Changelog ==

= 0.5 =
* Fix issue where WordPress could not load the importer.

= 0.1 =
* Initial release
