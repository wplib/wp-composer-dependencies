<div data-spotim-module="recirculation" data-spot-id="<?php echo esc_attr( $spot_id ); ?>"></div>
<script async src="<?php echo esc_url( 'https://recirculation.spot.im/spot/' . $spot_id ); ?>" data-spotim-script="recirculation"></script> 
