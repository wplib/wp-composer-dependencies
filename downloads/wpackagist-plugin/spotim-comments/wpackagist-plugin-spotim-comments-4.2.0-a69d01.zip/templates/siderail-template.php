<div data-spotim-module="siderail" data-spot-id="<?php echo esc_attr( $spot_id ); ?>"></div>
<script async="async" src="<?php echo esc_url( 'https://mc-siderail.spot.im/spot/' . $spot_id ); ?>" data-spotim-script="siderail"></script>
