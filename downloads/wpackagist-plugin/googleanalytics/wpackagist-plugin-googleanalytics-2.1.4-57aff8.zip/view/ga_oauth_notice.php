<div class="ga-alert ga-alert-warning">
	<?php echo $msg; ?>
</div>
