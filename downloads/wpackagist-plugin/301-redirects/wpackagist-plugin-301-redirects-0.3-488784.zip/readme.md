301 Redirects
----------
This plugin helps you add 301 Redirects to your Wordpress site.

Use
----------
This plugin is perfect for when you are creating a new site for a client and need to manage all of the redirects from the old site to the new one.  

Find the link to the installed 301 Redirects in the Settings tab in the admin menu.

It will set up a new table in your wordpress install called 'ts_redirects' that will store all of your redirect information.
