<h2><?php _e( 'Want to customize your payment forms even more?', 'stripe' ); ?></h2>
<p>
	<?php _e( 'By upgrading to WP Simple Pay Pro, you get access to powerful features such as custom fields, user-entered amounts, coupon codes, tax rate support, Stripe Subscriptions, and so much more!', 'stripe' ); ?>
</p>
