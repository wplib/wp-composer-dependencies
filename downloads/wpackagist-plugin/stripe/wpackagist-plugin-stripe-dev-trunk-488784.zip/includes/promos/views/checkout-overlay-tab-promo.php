<h2><?php _e( 'To Do', 'stripe' ); ?></h2>
<p>
	<?php _e( "To Do", 'stripe' ); ?>
</p>
