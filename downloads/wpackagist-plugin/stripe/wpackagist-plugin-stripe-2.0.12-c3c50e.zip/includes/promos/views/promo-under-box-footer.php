<p>
	<a href="<?php echo simpay_pro_upgrade_url( 'under-box-promo' ); ?>"
	   class="simpay-upgrade-btn simpay-upgrade-btn-large" target="_blank">
		<?php _e( 'Click here to Upgrade', 'stripe' ); ?>
	</a>
</p>

</div>
