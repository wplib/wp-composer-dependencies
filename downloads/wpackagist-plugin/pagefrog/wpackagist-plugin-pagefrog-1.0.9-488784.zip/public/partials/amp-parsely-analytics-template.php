<amp-analytics type="parsely">
<script type="application/json">
{
  "vars": {
    "apikey": "<?php echo $analytics->get_parsely_api_key(); ?>"
  }
}
</script>
</amp-analytics>