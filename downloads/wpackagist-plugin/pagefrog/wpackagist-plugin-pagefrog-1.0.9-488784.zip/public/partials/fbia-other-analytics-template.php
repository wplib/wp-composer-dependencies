<figure class="op-tracker">
    <iframe>
        <script>
            <?php echo $analytics->get_other_fbia_analytics_code(); ?>
        </script>
    </iframe>
</figure>