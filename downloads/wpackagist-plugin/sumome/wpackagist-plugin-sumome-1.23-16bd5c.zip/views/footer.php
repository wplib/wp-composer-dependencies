<!--footer-->
<div class="row">
  <div class="large-12 columns footer">
    <div class="sumome-plugin-center social-media">
      <h4 class="list-number-title">Show Us Love and Give Us a Follow</h4>
      <div>
        <a href="https://twitter.com/SumoMe" target="_blank"><img class="appsumo-twitter" src="<?php print plugins_url('images/twitter.png', dirname(__FILE__))?>"></a>
        <a href="https://www.facebook.com/sumome/" target="_blank"><img class="appsumo-facebook" src="<?php print plugins_url('images/facebook.png', dirname(__FILE__))?>"></a>
        <a href="https://www.instagram.com/sumome/" target="_blank"><img class="appsumo-instagram" src="<?php print plugins_url('images/instagram.png', dirname(__FILE__))?>"></a>
      </div>
    </div>


    <div class="sumome-plugin-center">Need to restore an existing account?
      <div class="sumome-plugin-linkalike sumome-link-button sumome-tile-advanced-settings item-tile sumome-popup-no-dim" data-name="sumome-control-advanced-settings" data-title="">Click here</div>
    </div>

  </div>
</div>
