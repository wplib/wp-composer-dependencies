jQuery(document).ready(function($){

	var myOptions = {
	    palettes: false,
	    width: 300,
	    mode: 'hsl'
	};

    $('.faqconc-color-field').wpColorPicker(myOptions);
    
});