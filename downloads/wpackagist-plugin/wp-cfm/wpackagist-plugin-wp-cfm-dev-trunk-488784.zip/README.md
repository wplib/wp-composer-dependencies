#### Manage and deploy WordPress configuration changes

WP-CFM lets you copy database configuration to / from the filesystem. Easily deploy configuration changes without needing to copy the entire database. WP-CFM is similar to Drupal's Features module.

[See WP-CFM on WordPress.org](http://wordpress.org/plugins/wp-cfm/)
