<?php

function dokan_remove_notice_meta_257() {
    delete_option( 'dokan_4th_yr_aniv_44_perc_discount_tracking_notice' );
}

dokan_remove_notice_meta_257();
