<?php

if (!defined('ABSPATH')) { die('No direct access.'); }

// Use this file to add any temporary code to a release. 
// Make sure to uncomment where it's loaded from in ml-slider.php