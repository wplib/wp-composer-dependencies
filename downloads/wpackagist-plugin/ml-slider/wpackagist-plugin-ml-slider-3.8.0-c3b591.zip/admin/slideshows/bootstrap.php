<?php

if (!defined('ABSPATH')) die('No direct access.');

/**
 * Use this file to load in models and libraries.
 */
require_once(dirname(__FILE__) . '/Slideshows.php');