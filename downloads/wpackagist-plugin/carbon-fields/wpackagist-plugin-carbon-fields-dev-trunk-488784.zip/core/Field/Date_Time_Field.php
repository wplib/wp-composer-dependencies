<?php

namespace Carbon_Fields\Field;

/**
 * Date and time picker field class.
 */
class Date_Time_Field extends Time_Field {
	protected $timepicker_type = 'datetimepicker';
}
