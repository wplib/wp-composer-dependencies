<div class="field-custom description description-wide carbon-nav-menu-row carbon-container">
	<fieldset class="container-holder carbon-nav-menu-container container-<?php echo $this->id; ?>" data-json="<?php /* TO DO - usage on ajax adding elements */ echo urlencode( json_encode( $this->to_json( false ) ) ); ?>"></fieldset>
</div>
