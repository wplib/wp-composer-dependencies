/**
 * The empty-list view.
 *
 * @since 1.0.0
 */
var EmptyListView = Marionette.ItemView.extend( {

    template : '#tmpl-tailor-control-list-empty'

} );

module.exports = EmptyListView;