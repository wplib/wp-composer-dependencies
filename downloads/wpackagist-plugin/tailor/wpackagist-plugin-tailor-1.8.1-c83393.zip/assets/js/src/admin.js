require( './shared/utility/ajax' );

require( './admin/components/icon-kits' );