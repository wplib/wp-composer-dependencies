var EmptyModalView = Marionette.ItemView.extend( {

    className : 'empty',

    template : '#tmpl-tailor-modal-empty'

} );

module.exports = EmptyModalView;