<?php
/**
 * Placeholder for bbPress plugin bridge.
 *
 * @package BuddyPress
 * @subpackage ForumsbbPress
 * @since 1.1.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
