<?php
/**
 * *** IMPORTANT ****
 * This file will stop people from accessing your bbPress installation directly.
 * It is very important from a security standpoint that this file is not moved.
 * Your actual bb-config.php file will be installed in the root of your WordPress
 * installation once you have set up the forums component in BuddyPress.
 *
 * @package BuddyPress
 * @subpackage ForumsbbPressConfig
 * @since 1.1.0
 */

header("HTTP/1.0 403 Forbidden"); die;
