<?php
/**
 * BP Nouveau Group's membership requests template.
 *
 * @since 3.0.0
 * @version 3.0.0
 */
?>

<div class="requests" data-bp-list="group_requests">

	<div id="bp-ajax-loader"><?php bp_nouveau_user_feedback( 'group-requests-loading' ); ?></div>

</div><!-- .requests -->
