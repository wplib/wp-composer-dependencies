<?php
require_once PODS_DIR . 'classes/fields/pick.php';

/**
 * Create a faux pick field type for comment traversal.
 *
 * @package Pods\Fields
 */
class PodsField_Taxonomy extends PodsField_Pick {

}
