<p><?php _e( 'The following are settings provided for advanced site configurations.', 'pods' ); ?></p>
