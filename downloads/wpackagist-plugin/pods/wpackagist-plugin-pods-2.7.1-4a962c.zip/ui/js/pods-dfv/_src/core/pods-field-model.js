/*global jQuery, _, Backbone, Marionette */
export const PodsDFVFieldModel = Backbone.Model.extend( {
	defaults: {
		htmlAttr   : {},
		fieldConfig: {}
	}
} );