<?php echo PodsForm::label( $name, $options ); ?>

<?php echo PodsForm::field( $name, $value, $type, $options, $pod, $id ); ?>

<?php echo PodsForm::comment( $name, null, $options ); ?>