{
    "sProcessing":   "Pracujem...",
    "sLengthMenu":   "Zobraz _MENU_ záznamov",
    "sZeroRecords":  "Neboli nájdené žiadne záznamy",
    "sInfo":         "Záznamy _START_ až _END_ z celkovo _TOTAL_",
    "sInfoEmpty":    "Záznamy 0 až 0 z celkovo 0",
    "sInfoFiltered": "(filtrované z celkovo _MAX_ záznamov)",
    "sInfoPostFix":  "",
    "sSearch":       "Hľadaj:",
    "sUrl":          "",
    "oPaginate": {
        "sFirst":    "Prvá",
        "sPrevious": "Predchádzajúca",
        "sNext":     "Ďalšia",
        "sLast":     "Posledná"
    }
}
