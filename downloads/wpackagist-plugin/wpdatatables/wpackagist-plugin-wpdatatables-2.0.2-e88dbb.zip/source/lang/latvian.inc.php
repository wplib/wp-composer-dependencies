{
    "sProcessing":   "Uzgaidiet...",
    "sLengthMenu":   "Rādīt _MENU_ ierakstus",
    "sZeroRecords":  "Nav atrasti vaicājumam atbilstoši ieraksti",
    "sInfo":         "Parādīti _START_. līdz _END_. no _TOTAL_ ierakstiem",
    "sInfoEmpty":    "Nav ierakstu",
    "sInfoFiltered": "(atlasīts no pavisam _MAX_ ierakstiem)",
    "sInfoPostFix":  "",
    "sSearch":       "Meklēt:",
    "sUrl":          "",
    "oPaginate": {
        "sFirst":    "Pirmā",
        "sPrevious": "Iepriekšējā",
        "sNext":     "Nākošā",
        "sLast":     "Pēdējā"
    }
}
