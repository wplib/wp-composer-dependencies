<?php defined('ABSPATH') or die("Cannot access pages directly."); ?>

<div class="overlayed wdt-preload-layer">
    <div class="preloader pl-lg">
        <svg class="pl-circular" viewBox="25 25 50 50">
            <circle class="plc-path" cx="50" cy="50" r="20"></circle>
        </svg>
    </div>
</div>