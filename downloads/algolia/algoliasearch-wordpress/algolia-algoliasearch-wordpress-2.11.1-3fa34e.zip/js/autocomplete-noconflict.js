window.algoliaAutocomplete = autocomplete.noConflict();
