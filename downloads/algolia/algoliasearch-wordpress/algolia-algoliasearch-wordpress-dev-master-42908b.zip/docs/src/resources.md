---
title: Additional Resources
description: You want to go further in your understanding of Algolia? Explore our resources!
layout: page.html
---

## Resources

 - 360° overview of Algolia: https://www.algolia.com/doc/getting-started
 - Discover Algolia's customers: https://www.algolia.com/customers
 - Read our Blog articles: https://blog.algolia.com/
 - Join the community: https://community.algolia.com/
 - Online support: http://stackoverflow.com/questions/tagged/algolia+wordpress
 - Contribute to Algolia's projects: https://github.com/algolia
 - Contribute to this plugin: https://github.com/algolia/algoliasearch-wordpress
