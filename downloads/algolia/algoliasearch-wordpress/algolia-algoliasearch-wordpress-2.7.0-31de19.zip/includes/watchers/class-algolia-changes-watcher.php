<?php

interface Algolia_Changes_Watcher
{
	public function watch();
}
