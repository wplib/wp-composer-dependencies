---
layout: home.html
title: Algolia Search plugin for WordPress
metaTitle: Algolia Search for WordPress
punchline: Help your users find what they’re looking for <br> at the speed of thought!
description: Algolia Search plugin for WordPress is a drop in replacement for WordPress search. It also provides an optional "as you type" auto-complete experience.
bodyClass: home
---
