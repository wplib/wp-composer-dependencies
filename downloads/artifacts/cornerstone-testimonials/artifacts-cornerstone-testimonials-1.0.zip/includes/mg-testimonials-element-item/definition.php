<?php

/**
 * Element Definition: "Mg Testimonials Element Item"
 */

class Mg_Testimonials_Element_Item
{
	
	public function ui()
	{
		return array(
			'title' => __('Testimonial Item', 'mg-testimonials')
		);
	}
	public function flags()
	{
		return array(
			'child' => true
		);
	}
	
}