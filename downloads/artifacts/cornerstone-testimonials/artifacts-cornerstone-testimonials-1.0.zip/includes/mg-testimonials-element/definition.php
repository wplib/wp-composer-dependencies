<?php

/**
 * Element Definition: "Mg Testimonials Element"
 */

class Mg_Testimonials_Element
{
	
	public function ui()
	{
		return array(
			'title' => __( 'Testimonials', 'mg-testimonials' ),
			'icon_group' => 'mg-testimonials'
		);
	}
}