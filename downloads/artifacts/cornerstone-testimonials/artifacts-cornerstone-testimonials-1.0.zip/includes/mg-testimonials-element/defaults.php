<?php

/**
 * Defaults Values
 */

return array(
	'id'       => '',
	'class'    => '',
	'style'    => '',
	'type'	   => 'mg-grid',
	'layout'	=> 'mg-style1',
	'background' => '',
	'contcolor' => '',
	'identitycolor'=> '',
	'columns'	=> 'mg-two-col',
	'autoplay' => true,
	'autoplay_time' => 3,
	'nav_button' =>true,
	'slider_dots' =>true,
	'navcolor' =>'',
	'navbgcolor' =>'',
);