<?php

/**
 * Element Controls
 */

return array(
	
	'elements' => array(
		'type' => 'sortable',
		'options' => array(
			'element' => 'mg-testimonials-element-item',
			'newTitle' => __('Testimonial %s', 'mg-testimonials'),
			'floor' => 1,
			'title_field' => 'heading'
		),
		'context' => 'content',
		'suggest' => array(
			array(
				'heading' => __('Testimonial 1', 'mg-testimonials')
			),
			array(
				'heading' => __('Testimonial 2', 'mg-testimonials')
			)
		)
	),
	'type' => array(
		'type' => 'select',
		'ui' => array(
			'title' => __('Type', 'mg-testimonials'),
			'tooltip' => __('There are multiple veiw types for different situations. Select the one that best suits your needs.', 'mg-testimonials')
		),
		'options' => array(
			'choices' => array(
				array(
					'value' => 'testimonials-grid',
					'label' => __('Grid', 'mg-testimonials')
				),
				array(
					'value' => 'testimonials-slider',
					'label' => __('Slider', 'mg-testimonials')
				)
			)
		)
	),
	'layout' => array(
		'type' => 'select',
		'ui' => array(
			'title' => __('Style', 'mg-testimonials'),
			'tooltip' => __('There are multiple style for different situations. Select the one that best suits your needs.', 'mg-testimonials')
		),
		'options' => array(
			'choices' => array(
				array(
					'value' => 'mg-style1',
					'label' => __('Style 1', 'mg-testimonials')
				),
				array(
					'value' => 'mg-style2',
					'label' => __('Style 2', 'mg-testimonials')
				),
				array(
					'value' => 'mg-style3',
					'label' => __('Style 3', 'mg-testimonials')
				)
			)
		)
	),
	'columns' => array(
		'type' => 'select',
		'ui' => array(
			'title' => __('Columns', 'mg-testimonials'),
			'tooltip' => __('Select how many columns of items should be displayed on larger screens. These will update responsively based on screen size.', 'mg-testimonials')
		),
		'options' => array(
			'choices' => array(
				array(
					'value' => 'mg-one-col',
					'label' => __('1', 'mg-testimonials')
				),
				array(
					'value' => 'mg-two-col',
					'label' => __('2', 'mg-testimonials')
				),
				array(
					'value' => 'mg-three-col',
					'label' => __('3', 'mg-testimonials')
				)
				
			)
		)
	),
	'autoplay' => array(
		'type' => 'toggle',
		'ui' => array(
			'title' => __('Slider Autoplay', 'mg-testimonials'),
			'tooltip' => __('Select On if you want to play the Slider autometicaly on page load.( only for slider type)', 'mg-testimonials')
		),
		'condition' => array(
			'type' => 'testimonials-slider'
		)
	),
	'autoplay_time' => array(
		'type' => 'number',
		'ui' => array(
			'title' => __('Autoplay time(in seconds)', 'mg-testimonials'),
			'tooltip' => __('Enter the time after which the items should automatically scroll', 'mg-testimonials')
		),
		'condition' => array(
			'type' => 'testimonials-slider'
		)
	),
	'nav_button' => array(
		'type' => 'toggle',
		'ui' => array(
			'title' => __('Slider Next/Prev Buttons', 'mg-testimonials'),
			'tooltip' => __('Select On if you want to Show Next/Prev Buttons of Slider.( only for slider type)', 'mg-testimonials')
		),
		'condition' => array(
			'type' => 'testimonials-slider'
		)
	),
	'slider_dots' => array(
		'type' => 'toggle',
		'ui' => array(
			'title' => __('Slider Pagination Dots', 'mg-testimonials'),
			'tooltip' => __('Select On if you want to Show Pagination Dots of Slider.( only for slider type)', 'mg-testimonials')
		),
		'condition' => array(
			'type' => 'testimonials-slider'
		)
	),
	'background' => array(
		'type' => 'color',
		'ui' => array(
			'title' => __('Background', 'mg-testimonials'),
			'tooltip' => __('Select background color ', 'mg-testimonials')
		)
	),
	'contcolor' => array(
		'type' => 'color',
		'ui' => array(
			'title' => __('Content color', 'mg-testimonials'),
			'tooltip' => __('Select color', 'mg-testimonials')
		)
	),
	'identitycolor' => array(
		'type' => 'color',
		'ui' => array(
			'title' => __('Identity color', 'mg-testimonials'),
			'tooltip' => __('Select identity color', 'mg-testimonials')
		)
	),
	'navcolor' => array(
		'type' => 'color',
		'ui' => array(
			'title' => __('Navigation color', 'mg-testimonials'),
			'tooltip' => __('Select Navigation color', 'mg-testimonials')
		),
		'condition' => array(
			'type' => 'testimonials-slider'
		)
	),
	'navbgcolor' => array(
		'type' => 'color',
		'ui' => array(
			'title' => __('Navigation background', 'mg-testimonials'),
			'tooltip' => __('Select Navigation background color', 'mg-testimonials')
		),
		'condition' => array(
			'type' => 'testimonials-slider'
		)
	)
	
);