<?php
	class Mg_Testimonials{
		/**
	     * Bootstraps the class and hooks required actions & filters.
	     *
	     */
		function __construct(){
			add_action( 'wp_enqueue_scripts', array( $this, 'mg_testimonials_enqueue' ) );
			add_action( 'cornerstone_register_elements', array( $this, 'mg_testimonials_register_elements' ) );
			add_filter( 'cornerstone_icon_map', array( $this, 'mg_testimonials_icon_map' ) );
		}
		function mg_testimonials_register_elements() {
			cornerstone_register_element( 'Mg_Testimonials_Element', 'mg-testimonials-element', MG_TESTIMONIALS_PATH . 'includes/mg-testimonials-element' );
			cornerstone_register_element( 'Mg_Testimonials_Element_Item', 'mg-testimonials-element-item', MG_TESTIMONIALS_PATH . 'includes/mg-testimonials-element-item' );
		}
		function mg_testimonials_enqueue() {
			wp_enqueue_style( 'mg_testimonials-style', MG_TESTIMONIALS_URL . '/assets/styles/mg-testimonials.css', array(), '1.0' );	
			wp_enqueue_script( 'owl-carousel-js', MG_TESTIMONIALS_URL . '/assets/js/owl.carousel.min.js', array('jquery'), '1.0' );	
		}
		function mg_testimonials_icon_map( $icon_map ) {
			$icon_map['mg-testimonials'] = MG_TESTIMONIALS_URL . 'assets/svg/icons.svg';
			return $icon_map;
		}
	}