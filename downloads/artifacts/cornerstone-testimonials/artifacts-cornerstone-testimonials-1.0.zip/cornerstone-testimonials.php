<?php
/*
Plugin Name: Testimonials for Cornerstone
Plugin URI: http://magnigenie.com/
Description: This plugins adds a testimonial element to cornerstone page builder
Version: 1.0
Author: MagniGenie
Author URI: http://magnigenie.com
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

define( 'MG_TESTIMONIALS_PATH', plugin_dir_path( __FILE__ ) );
define( 'MG_TESTIMONIALS_URL', plugin_dir_url( __FILE__ ) );

require MG_TESTIMONIALS_PATH . '/includes/class-testimonials.php' ;

new Mg_Testimonials();

