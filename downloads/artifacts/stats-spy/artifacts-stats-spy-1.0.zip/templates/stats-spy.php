<?php
  function sort_by_store_name ($a, $b) {
    return ($a->store_name < $b->store_name) ? -1 : 1;
  }

  $stats_spy_data = get_query_var('1thirteen-stats-spy-data');
  usort($stats_spy_data->seller_stats, "sort_by_store_name");
?>

<table class="onethirteen-stats-spy" style="width: 100%;">
  <thead style="text-align: left;">
    <tr>
      <th>Seller Name</th>
      <th>Pageviews</th>
      <th>All Orders</th>
      <th>Completed Orders</th>
      <th>Sales</th>
    </tr>
  </thead>
  <tbody>

  <?php
    foreach ($stats_spy_data->seller_stats as $seller) {
  ?>
    <tr>
      <td>
        <a href=\"<?php echo $seller->edit_link; ?>\"><?php echo $seller->store_name; ?></a>
        <br/>
        <span><?php echo $seller->display_name; ?></span>
      </td>
      <td><?php echo $seller->page_views; ?></td>
      <td><?php echo $seller->total_orders_count; ?></td>
      <td><?php echo $seller->completed_orders_count; ?></td>
      <td><?php echo $seller->formatted_sales; ?></td>
    </tr>
  <?php
    }
  ?>

  </tbody>
  <tfoot>
    <tr>
      <td>Totals:</td>
      <td><?php echo $stats_spy_data->page_views; ?></td>
      <td><?php echo $stats_spy_data->total_orders_count; ?></td>
      <td><?php echo $stats_spy_data->completed_orders_count; ?></td>
      <td><?php echo $stats_spy_data->formatted_sales; ?></td>
    </tr>
  </tfoot>
</table>