<?php

/**
 * Element Controls : Countdown
 */

return array(

	// Set date

	// 'date' => array(
	// 	'type'    => 'date',
	// 	'ui' => array(
	// 		'title' => __( 'Set Date', 'essential-addons-cs' ),
	// 	),
	// 	'options' => array(
	// 	'choose_format' => false,
	// 	'default_format'   => 'Do YYYY/M/D',
	// 	)
	// ),

	// Set Date

	'countdown_date' => array(
		'type'    => 'text',
		'ui' => array(
			'title'   => __( 'Set Date (YYYY/MM/DD)', 'essential-addons-cs' ),
			'tooltip' => __( 'Set the date when the countdown will finish.', 'essential-addons-cs' ),
		),
		'context' => 'content',
    'suggest' => __( 'YYYY/MM/DD', 'essential-addons-cs' ),
	),


	// Number font size

	'number_font_size' => array(
		'type'    => 'number',
		'ui' => array(
			'title'   => __( 'Set Number Font Size (px)', 'essential-addons-cs' ),
			'tooltip' => __( 'Set the font size for countdown numbers', 'essential-addons-cs' ),
		),
    'suggest' => __( '72', 'essential-addons-cs' ),
	),

	// Number Text Color

	'number_text_color' => array(
	 	'type' => 'color',
	 	'ui' => array(
			'title'   => __( 'Number Text Color', 'essential-addons-cs' ),
		)
	),


	// Show Label

	'show_label' => array(
		'type'    => 'toggle',
		'ui' => array(
			'title'   => __( 'Show Labels?', 'essential-addons-cs' ),
			'tooltip' => __( 'Show or hide labels (i.e. Days, Months etc.)', 'essential-addons-cs' ),
		)
	),


	// Label font size

	'label_font_size' => array(
		'type'    => 'number',
		'ui' => array(
			'title'   => __( 'Set Label Font Size (px)', 'essential-addons-cs' ),
			'tooltip' => __( 'Set the font size for countdown labels (i.e. Days, Hours)', 'essential-addons-cs' ),
		),
		'condition' => array(
      'show_label' => true
    ),
    'suggest' => __( '18', 'essential-addons-cs' ),
	),


	// Label Color

	'label_text_color' => array(
	 	'type' => 'color',
	 	'ui' => array(
			'title'   => __( 'Label Text Color', 'essential-addons-cs' ),
		),
		'condition' => array(
      'show_label' => true
    ),
	),

	// Item Spacing

	'item_padding' => array(
	 	'type' => 'dimensions',
	 	'ui' => array(
			'title'   => __( 'Spacing within numbers', 'essential-addons-cs' )
		)
	),


	// Add border

	'add_border' => array(
		'type'    => 'toggle',
		'ui' => array(
			'title'   => __( 'Add border to counter numbers?', 'essential-addons-cs' ),
			'tooltip' => __( 'Add border to each counter numbers', 'essential-addons-cs' ),
		)
	),

	// Border width

	'item_border_width' => array(
		'type'    => 'number',
		'ui' => array(
			'title'   => __( 'Border width', 'essential-addons-cs' ),
			'tooltip' => __( 'Set border width in pixel value', 'essential-addons-cs' ),
		),
    'suggest' => __( '1', 'essential-addons-cs' ),

		'condition' => array(
      'add_border' => true
    )
	),

	// Border Color

	'item_border_color' => array(
	    'type' => 'color',
	    'ui' => array(
	        'title'   => __( 'Border Color', 'essential-addons-cs' ),
	        'tooltip' => __( 'Set border color', 'essential-addons-cs' ),
	    ),

		'condition' => array(
      'add_border' => true
    )

	),

);