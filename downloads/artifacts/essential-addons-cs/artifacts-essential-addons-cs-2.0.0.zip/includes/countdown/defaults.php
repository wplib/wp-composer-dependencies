<?php

/**
 * Defaults Values : Countdown
 */

return array(
	'id'              		 => '',
	'class'           		 => '',
	'style'            		 => '',
	'countdown_date'    	 => '2020/01/01',
	'number_font_size'       => '72',
	'number_text_color'   	 => '#333',
	'show_label'   			 => true,
	'label_font_size'        => '18',
	'label_text_color'   	 => '#333',
	'item_padding'   		 => array( '10px', '10px', '10px', '10px', 'linked'),
	'add_border'   			 => false,
	'item_border_width'    => 1,
	'item_border_color'    => 'rgba(0,0,0, .15)',
);