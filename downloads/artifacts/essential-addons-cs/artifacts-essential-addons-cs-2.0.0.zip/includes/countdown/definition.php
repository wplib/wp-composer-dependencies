<?php

/**
 * Element Definition : Countdown
 */

class EACS_Countdown {

	public function ui() {
		return array(
      'name'        => 'eacs-countdown',
      'title'       => __( 'EA Countdown', 'essential-addons-cs' ),
      'icon_group' => 'essential-addons-cs'
    );
	}

}