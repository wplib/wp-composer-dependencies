<?php

/**
 * Element Definition : Instagram Feed
 */

class EACS_Instagram_Feed {

	public function ui() {
		return array(
      'name'        => 'eacs-intstagram-feed',
      'title'       => __( 'EA Instagram Feed', 'essential-addons-cs' ),
      'icon_group' => 'essential-addons-cs'
    );
	}

}