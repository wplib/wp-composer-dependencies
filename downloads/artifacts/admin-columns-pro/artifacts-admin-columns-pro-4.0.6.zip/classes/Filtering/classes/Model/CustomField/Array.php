<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ACP_Filtering_Model_CustomField_Array extends ACP_Filtering_Model_CustomField {

	// Disable Filtering
	public function register_settings() {
	}

}
