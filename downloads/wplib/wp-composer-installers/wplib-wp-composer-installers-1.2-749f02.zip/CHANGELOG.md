# Changelog

## 1.2
Changed from type `wordpress-devops-core` to just `wordpress-devops` to support changes for CircleCI 2.0 in [WP DevOps 0.2.0](https://github.com/wplib/wp-devops). 