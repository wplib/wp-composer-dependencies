<?php

/**
 * Class WPLib_User_Model_Default
 *
 * The Default Model Class for Users
 *
 * @property WPLib_User_Default $owner
 */
class WPLib_User_Model_Default extends WPLib_User_Model_Base {
}

