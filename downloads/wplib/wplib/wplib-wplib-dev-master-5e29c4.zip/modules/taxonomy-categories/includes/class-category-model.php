<?php

/**
 * Class WPLib_Category_Model
 *
 * @mixin WPLib_Category_View
 *
 * @method WPLib_Category_View view()
 */
class WPLib_Category_Model extends WPLib_Term_Model_Base {

}
