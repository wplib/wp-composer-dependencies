<?php

/**
 * Class WPLib_Plugins
 */
class WPLib_Plugins extends WPLib_Module_Base {

	static function on_load() {

	}

}
WPLib_Plugins::on_load();
