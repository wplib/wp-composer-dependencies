<?php

/**
 * Class WPLib_Post_Model
 *
 * @mixin WPLib_Post_View
 * @method WPLib_Post_View view()
 *
 * @method WPLib_Post $owner
 */
class WPLib_Post_Model extends WPLib_Post_Model_Base {

}
