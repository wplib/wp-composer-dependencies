<?php

/**
 * Class WPLib_Post_View
 *
 * @mixin WPLib_Post_Model
 * @method WPLib_Post_Model model()
 *
 * @property WPLib_Post_Tag $owner
 */
class WPLib_Post_View extends WPLib_Post_View_Default {


}
