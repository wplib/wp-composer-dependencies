<?php

/**
 * Class WPLib_Page_View
 *
 * @mixin WPLib_Page_Model
 * @method WPLib_Page_Model model()
 *
 * @property WPLib_Page $owner
 *
 */
class WPLib_Page_View extends WPLib_Post_View_Base {

}
