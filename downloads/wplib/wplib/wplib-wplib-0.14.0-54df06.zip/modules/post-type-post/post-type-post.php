<?php

/**
 * Class WPLib_Post_Type_Post
 */
class WPLib_Post_Type_Post extends WPLib_Module_Base {

	const POST_TYPE      = 'post';

	const INSTANCE_CLASS = 'WPLib_Post';
}




