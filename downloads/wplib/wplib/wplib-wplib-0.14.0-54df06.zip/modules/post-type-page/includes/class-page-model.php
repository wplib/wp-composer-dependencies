<?php

/**
 * Class WPLib_Page_Model
 *
 * @mixin WPLib_Page_View
 * @method WPLib_Page_View view()
 * @property WPLib_Page $owner
 */
class WPLib_Page_Model extends WPLib_Post_Model_Base {

}
