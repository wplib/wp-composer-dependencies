<?php

/**
 * Class WPLib_Post_Type_Page
 */
class WPLib_Post_Type_Page extends WPLib_Module_Base {

	const POST_TYPE      = 'page';

	const INSTANCE_CLASS = 'WPLib_Page';

}


