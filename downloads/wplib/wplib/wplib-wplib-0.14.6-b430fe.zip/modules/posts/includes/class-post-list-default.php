<?php

class WPLib_Post_List_Default extends WPLib_Post_List_Base {

}
