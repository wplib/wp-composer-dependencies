<?php

/**
 * Class WPLib_View_Default
 *
 * Default Module class if no other class defined.
 */
abstract class WPLib_View_Default extends WPLib_View_Base {

}
