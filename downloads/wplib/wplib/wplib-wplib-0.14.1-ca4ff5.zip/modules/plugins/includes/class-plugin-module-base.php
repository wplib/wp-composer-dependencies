<?php

/**
 * Class WPLib_Plugin_Module_Base
 */
abstract class WPLib_Plugin_Module_Base extends WPLib_Module_Base {

	const PLUGIN_SLUG = null;

}
