<?php

/**
 * Class WPLib_Theme_Default
 */
class WPLib_Theme_Default extends WPLib_Theme_Base {


}
