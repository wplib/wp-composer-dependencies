<?php

class WPLib_User_List extends WPLib_List_Base {

}
