<?php

/**
 * Class WPLib_Post_Tag_View
 *
 * @mixin WPLib_Post_Tag_Model
 * @method WPLib_Post_Tag_Model model()
 * @property WPLib_Post_Tag $owner
 */
class WPLib_Post_Tag_View extends WPLib_Term_View_Base {

}
