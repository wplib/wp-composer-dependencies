<?php

/**
 * Class WPLib_App_Base
 */
abstract class WPLib_App_Base extends WPLib {

}
