<?php

/**
 * Class WPLib_Category_View
 *
 * @mixin WPLib_Category_Model
 * @property WPLib_Category $controller
 *
 * @method WPLib_Category_Model model()
 */
class WPLib_Category_View extends WPLib_Term_View_Base {

}
