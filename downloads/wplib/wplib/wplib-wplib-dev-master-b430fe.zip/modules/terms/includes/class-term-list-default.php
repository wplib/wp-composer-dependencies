<?php

class WPLib_Term_List_Default extends WPLib_Term_List_Base {

}
