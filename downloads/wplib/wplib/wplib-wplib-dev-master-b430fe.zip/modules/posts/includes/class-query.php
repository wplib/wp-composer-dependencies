<?php

/**
 * Class WPLib_Query
 */
class WPLib_Query extends WP_Query {


}
