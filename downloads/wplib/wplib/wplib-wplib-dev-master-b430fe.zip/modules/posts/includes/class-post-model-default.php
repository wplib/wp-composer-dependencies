<?php

/**
 * Class WPLib_Post_Model_Default
 *
 * The Default Model Class for Posts.
 *
 * @property WPLib_Post_Base $owner
 */
class WPLib_Post_Model_Default extends WPLib_Post_Model_Base {
}
