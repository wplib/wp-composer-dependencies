<?php

/**
 * Class WPLib_Model_Default
 *
 * Default Module class if no other class defined.
 */
abstract class WPLib_Model_Default extends WPLib_Model_Base {

}

