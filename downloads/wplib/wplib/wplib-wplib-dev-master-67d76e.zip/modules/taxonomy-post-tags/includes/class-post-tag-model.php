<?php

/**
 * Class WPLib_Post_Tag_Model
 *
 * @mixin WPLib_Post_Tag_View
 * @method WPLib_Post_Tag_View view()
 * @property WPLib_Post_Tag $owner
 */
class WPLib_Post_Tag_Model extends WPLib_Term_Model_Base {

}
