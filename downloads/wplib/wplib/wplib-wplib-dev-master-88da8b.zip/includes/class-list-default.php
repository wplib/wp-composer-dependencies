<?php

/**
 * Class WPLib_List_Default
 */
abstract class WPLib_List_Default extends WPLib_List_Base {}
