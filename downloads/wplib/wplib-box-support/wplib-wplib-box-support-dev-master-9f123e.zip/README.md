# WordPress Plugin for WPLib Box Support

This plugin is designed to provide support for [**WPLib Box**](https://github.com/wplib/wplib-box): 
> _"The Best Local Dev Server for WordPress Developers."_
