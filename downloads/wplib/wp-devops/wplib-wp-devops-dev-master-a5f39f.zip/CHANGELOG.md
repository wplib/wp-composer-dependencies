# WP DevOps Changelog

##0.2.4
- Changed from 100 (??) to 1000 (???) files for unchunking. 