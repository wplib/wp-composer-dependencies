#WP DevOps Changelog

## 2.0.0
- Support for CircleCI 2.0

 


