<?php

/**
 * Define paths
 */
define( 'CORE_PATH', '' );
define( 'CONTENT_PATH', 'wp-content' );
define( 'PORT', '8080' );

