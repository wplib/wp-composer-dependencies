#!/usr/bin/env bash
#
# devops/core/test.sh
#
#   Placeholder for testing
#
#   See: https://github.com/phpro/grumphp
#   See: https://codecov.io/
#

echo "No tests yet."