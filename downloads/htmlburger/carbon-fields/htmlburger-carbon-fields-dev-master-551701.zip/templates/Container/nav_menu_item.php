<div class="field-custom description description-wide carbon-nav-menu-row carbon-container" data-id="<?php echo $this->get_id(); ?>">
	<fieldset class="container-holder carbon-nav-menu-container container-<?php echo $this->get_id(); ?>" data-json="<?php echo urlencode( json_encode( $this->to_json( false ) ) ); ?>"></fieldset>
</div>
