/**
 * Return all sidebars.
 *
 * @param  {Object} state
 * @return {Object}
 */
export const getSidebars = state => state.sidebars;
