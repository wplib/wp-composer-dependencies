<?php

namespace Carbon_Fields\Field;

use Carbon_Fields\Exception\Incorrect_Syntax_Exception;

/**
 * Hidden field class.
 */
class Hidden_Field extends Field {

}
