<?php

if ( ! defined( 'WP_USE_EXT_MYSQL' ) ) {
	define( 'WP_USE_EXT_MYSQL', false );
}