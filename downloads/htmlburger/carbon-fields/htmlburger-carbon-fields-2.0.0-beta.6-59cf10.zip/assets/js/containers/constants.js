export const TYPE_COMMENT_META = 'comment_meta';
export const TYPE_NAV_MENU_ITEM = 'nav_menu_item';
export const TYPE_POST_META = 'post_meta';
export const TYPE_TERM_META = 'term_meta';
export const TYPE_THEME_OPTIONS = 'theme_options';
export const TYPE_USER_META = 'user_meta';
export const TYPE_WIDGET = 'widget';
