/**
 * External dependencies.
 */
import { Component } from '@wordpress/element';

class BlockSave extends Component {
	/**
	 * Render the component.
	 *
	 * @return {Object}
	 */
	render() {
		return null;
	}
}

export default BlockSave;
