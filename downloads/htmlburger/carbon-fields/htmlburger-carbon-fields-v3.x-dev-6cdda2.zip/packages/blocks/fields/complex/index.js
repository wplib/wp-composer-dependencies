/**
 * External dependencies.
 */
import produce from 'immer';
import { Component } from '@wordpress/element';
import { addFilter } from '@wordpress/hooks';
import {
	get,
	set,
	find,
	omit,
	assign,
	without,
	cloneDeep,
	findIndex
} from 'lodash';

/**
 * Carbon Fields dependencies.
 */
import { uniqueId } from '@carbon-fields/core';

class ComplexField extends Component {
	/**
	 * Local state.
	 *
	 * @type {Object}
	 */
	state = {
		collapsedGroups: []
	};

	/**
	 * Handles adding of group.
	 *
	 * @param  {Object}   group
	 * @param  {Function} callback
	 * @return {void}
	 */
	handleAddGroup = ( group, callback ) => {
		const {
			name,
			value,
			onChange
		} = this.props;

		const data = {};

		data._id = uniqueId();
		data._type = group.name;

		group.fields.reduce( ( accumulator, field ) => {
			accumulator[ field.base_name ] = field.default_value;

			return accumulator;
		}, data );

		onChange( name, value.concat( data ) );

		callback( data );
	}

	/**
	 * Handles cloning of group.
	 *
	 * @param  {string}   groupId
	 * @param  {Function} callback
	 * @return {void}
	 */
	handleCloneGroup = ( groupId, callback ) => {
		const {
			name,
			value,
			onChange
		} = this.props;

		const group = find( value, [ '_id', groupId ] );
		const index = value.indexOf( group );
		const clonedGroup = cloneDeep( group );

		clonedGroup._id = uniqueId();

		onChange( name, produce( value, ( draft ) => {
			draft.splice( index + 1, 0, clonedGroup );
		} ) );

		callback( clonedGroup );
	}

	/**
	 * Handles removing of group.
	 *
	 * @param  {string} groupId
	 * @return {void}
	 */
	handleRemoveGroup = ( groupId ) => {
		const {
			name,
			value,
			onChange
		} = this.props;

		const groupIndex = findIndex( value, [ '_id', groupId ] );

		onChange( name, produce( value, ( draft ) => {
			draft.splice( groupIndex, 1 );
		} ) );

		this.setState( ( { collapsedGroups } ) => ( {
			collapsedGroups: without( collapsedGroups, groupId )
		} ) );
	}

	/**
	 * Handles expanding/collapsing of group.
	 *
	 * @param  {string} groupId
	 * @return {void}
	 */
	handleToggleGroup = ( groupId ) => {
		this.setState( ( { collapsedGroups } ) => {
			if ( collapsedGroups.indexOf( groupId ) > -1 ) {
				collapsedGroups = without( collapsedGroups, groupId );
			} else {
				collapsedGroups = [ ...collapsedGroups, groupId ];
			}

			return { collapsedGroups };
		} );
	}

	/**
	 * Handles expanding/collapsing of all groups.
	 *
	 * @return {void}
	 */
	handleToggleAllGroups = () => {
		const { value } = this.props;

		this.setState( ( { collapsedGroups } ) => {
			if ( collapsedGroups.length !== value.length ) {
				collapsedGroups = value.map( ( group ) => group._id );
			} else {
				collapsedGroups = [];
			}

			return { collapsedGroups };
		} );
	}

	/**
	 * Handles setuping of group.
	 *
	 * @param  {Object} group
	 * @param  {Object} props
	 * @return {Object}
	 */
	handleGroupSetup = ( group, props ) => {
		const fields = get( find( this.props.field.groups, [ 'name', group._type ] ), 'fields', [] );
		const values = omit( group, [ '_id', '_type' ] );

		return assign( {}, props, {
			key: group._id,
			id: group._id,
			fields: fields,
			collapsed: this.state.collapsedGroups.indexOf( group._id ) > -1,
			context: 'block',
			values
		} );
	}

	/**
	 * Handles setuping of group's field.
	 *
	 * @param  {Object} field
	 * @param  {Object} props
	 * @param  {Object} groupProps
	 * @return {Object}
	 */
	handleGroupFieldSetup = ( field, props, groupProps ) => {
		const id = `${ groupProps.id }-${ field.base_name }`;
		const value = get( groupProps, `values.${ field.base_name }` );

		return assign( {}, props, {
			key: id,
			id: id,
			field,
			value,
			onChange: this.handleGroupFieldChange
		} );
	}

	/**
	 * Handles the change of group field.
	 *
	 * @param  {string} fieldId
	 * @param  {mixed}  fieldValue
	 * @return {void}
	 */
	handleGroupFieldChange = ( fieldId, fieldValue ) => {
		const {
			id,
			value,
			onChange
		} = this.props;

		onChange( id, produce( value, ( draft ) => {
			const path = fieldId.split( '-' );
			const group = find( draft, [ '_id', path.shift() ] );

			set( group, path, fieldValue );
		} ) );
	}

	/**
	 * Renders the component.
	 *
	 * @return {Object}
	 */
	render() {
		const {
			handleGroupSetup,
			handleGroupFieldSetup,
			handleAddGroup,
			handleCloneGroup,
			handleRemoveGroup,
			handleToggleGroup,
			handleToggleAllGroups
		} = this;

		const { value, children } = this.props;

		const allGroupsAreCollapsed = this.state.collapsedGroups.length === value.length;

		return children( {
			allGroupsAreCollapsed,
			handleGroupSetup,
			handleGroupFieldSetup,
			handleAddGroup,
			handleCloneGroup,
			handleRemoveGroup,
			handleToggleGroup,
			handleToggleAllGroups
		} );
	}
}

addFilter( 'carbon-fields.complex-field.block', 'carbon-fields/blocks', ( OriginalComplexField ) => ( props ) => {
	const {
		id,
		field,
		name,
		value
	} = props;

	return (
		<ComplexField { ...props }>
			{ ( {
				allGroupsAreCollapsed,
				handleGroupSetup,
				handleGroupFieldSetup,
				handleAddGroup,
				handleCloneGroup,
				handleRemoveGroup,
				handleToggleGroup,
				handleToggleAllGroups
			} ) => (
				<OriginalComplexField
					groupIdKey="_id"
					groupFilterKey="_type"
					id={ id }
					field={ field }
					name={ name }
					value={ value }
					allGroupsAreCollapsed={ allGroupsAreCollapsed }
					onGroupSetup={ handleGroupSetup }
					onGroupFieldSetup={ handleGroupFieldSetup }
					onAddGroup={ handleAddGroup }
					onCloneGroup={ handleCloneGroup }
					onRemoveGroup={ handleRemoveGroup }
					onToggleGroup={ handleToggleGroup }
					onToggleAllGroups={ handleToggleAllGroups }
				/>
			) }
		</ComplexField>
	);
} );
