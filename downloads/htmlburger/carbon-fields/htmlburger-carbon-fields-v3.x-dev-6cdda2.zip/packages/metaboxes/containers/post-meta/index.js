/**
 * Internal dependencies.
 */
import './classic';
import './gutenberg';
import ContainerBase from '../../components/container-base';

export default ContainerBase;
