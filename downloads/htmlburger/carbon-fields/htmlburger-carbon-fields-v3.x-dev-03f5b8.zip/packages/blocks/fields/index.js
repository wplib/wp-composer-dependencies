/**
 * Internal dependencies.
 */
import './checkbox';
import './color';
import './complex';
import './file';
import './gravity-form';
import './hidden';
import './html';
import './radio';
import './radio-image';
import './select';
import './set';
import './sidebar';
import './text';
import './textarea';
