/**
 * The internal dependencies.
 */
import './text';
