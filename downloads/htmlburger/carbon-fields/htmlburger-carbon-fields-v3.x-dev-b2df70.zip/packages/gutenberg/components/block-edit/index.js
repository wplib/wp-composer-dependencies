/**
 * External dependencies.
 */
import { Component } from '@wordpress/element';

class BlockEdit extends Component {
	/**
	 * Render the component.
	 *
	 * @return {Object}
	 */
	render() {
		return null;
	}
}

export default BlockEdit;
