module.exports = {
	plugins: [
		['module-resolver', {
			root: ['./packages/gutenberg']
		}]
	]
};
