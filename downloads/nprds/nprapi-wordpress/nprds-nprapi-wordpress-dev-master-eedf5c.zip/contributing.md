# Contributing

The WordPress plugin is being developed as an Open Source plugin by NPR Digital Services. If you would like to suggest features or bug fixes, or better yet if you would like to contribute new features or bug fixes please contact Digital Services through our support page at [http://info.ds.npr.org/support.html](http://info.ds.npr.org/support.html).