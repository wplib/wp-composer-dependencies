<?php

/**
 * Defaults Values : Social Icons Item
 */

return array(
	'id'               => '',
	'class'            => '',
	'style'            => '',
	'social_icon'            => 'facebook',
	'icon_color'            => '#fff',
	'icon_bg_color'            => '#3b5998',	
	'icon_hover_color'            => '#fff',
	'icon_hover_bg_color'            => '#333',
	'link_url'            => 'https://facebook.com',
	'link_target'            => true,
);