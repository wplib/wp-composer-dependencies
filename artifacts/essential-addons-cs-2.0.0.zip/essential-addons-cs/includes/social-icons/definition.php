<?php

/**
 * Element Definition: Social Icons
 */

class EACS_Social_Icons {

	public function ui() {
		return array(
			'name'        => 'eacs-social-icons',
      		'title'	=> __( 'EA Social Icons', 'essential-addons-cs' ),
      		'icon_group' => 'essential-addons-cs'
    );
	}

	public function flags() {
		return array(
			'dynamic_child' => false
		);
	}

}