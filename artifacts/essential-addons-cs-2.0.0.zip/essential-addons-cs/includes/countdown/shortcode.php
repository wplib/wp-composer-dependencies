<?php

/**
 * Shortcode handler : Countdown
 */

/*
 * => VARS & INFO
 * ---------------------------------------------------------------------------*/

$randnum = rand(0,5000); 


//
// Dynamic classes
//
$show_label     = ( ($show_label == 1) ? "" : "no-label" );
$add_border   = ( ($add_border == 1) ? "border-enabled" : "" );

// Class, ID, Styles
$countdown_id = "eacs-countdown-".$randnum;
$class = "eacs-countdown " . " ". $show_label. " ". $add_border. " " . $class;

echo ('<script type="text/javascript" src="'. ESSENTIAL_ADDONS_CS_URL . 'assets/js/jquery.countdown.min.js"> </script>');

?>

<div <?php echo cs_atts( array( 'id' => $id, 'class' => $class, 'style' => $style ) ); ?>>
	<div id="<?php echo $countdown_id ?>">
    <div class="eacs-countdown-inner">
      <ul class="eacs-countdown-items">
        <li class="days"><span class="countdown-label">0 Days</span></li>
        <li class="hours"><span class="countdown-label">0 Hours</span></li>
        <li class="minutes"><span class="countdown-label">0 Minutes</span></li>
        <li class="seconds"><span class="countdown-label">0 Seconds</span></li>
      </ul>
      <div class="clearfix"></div>
    </div>
	</div>
</div>


<script type="text/javascript">


(function ($) {
    'use strict';

  $("<?php echo '#'.$countdown_id ?>").countdown("<?php echo $countdown_date; ?>", function(e) {

        var $this = $(this);

        $this.find('.days').html(e.strftime('%D <span class="countdown-label">Days</span>'));
        $this.find('.hours').html(e.strftime('%H <span class="countdown-label">Hours</span>'));
        $this.find('.minutes').html(e.strftime('%M <span class="countdown-label">Minutes</span>'));
        $this.find('.seconds').html(e.strftime('%S <span class="countdown-label">Seconds</span>'));
     });
    
}(jQuery));

</script>

<style type="text/css">

.eacs-countdown <?php echo '#'.$countdown_id; ?>  .eacs-countdown-inner li {
  font-size: <?php echo $number_font_size; ?>px;
  color: <?php echo $number_text_color; ?>;
  padding: <?php echo $item_padding; ?>;
}
.eacs-countdown <?php echo '#'.$countdown_id; ?>  .eacs-countdown-inner li > span.countdown-label {
  font-size: <?php echo $label_font_size; ?>px;
  color: <?php echo $label_text_color; ?>;
}

.eacs-countdown.border-enabled <?php echo '#'.$countdown_id; ?> .eacs-countdown-inner li {
  border: <?= $item_border_width ?>px solid <?= $item_border_color?>;
}
</style>