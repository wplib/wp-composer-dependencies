<?php
/*
Plugin Name: 1Thirteen - Stats Spy
Plugin URI: http://1thirteen.com/
Description: View page stats for each seller store on your site. This is a great tool to track stats for SEO and marketing research.
Version: 1.0
Author: 1Thirteen
Author URI: http://1thirteen.com/
License: GPL2
*/

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

if ( ! class_exists( 'OneThirteenStatsSpy' ) ) :

  class OneThirteenStatsSpy {
    public function __construct() {
      // Show the stats spy in admin dashboard
      add_action('dokan_admin_dashboard_metabox_left', array($this, 'show_dokan_stats_spy'), 1);
    }

    function show_dokan_stats_spy () {
      wp_register_style('onethirteen-stats-spy', plugins_url('assets/css/stats-spy.css', __FILE__), false, null);
      wp_enqueue_style('onethirteen-stats-spy');

      dokan_admin_dash_metabox('Dokan Stats Spy', array($this, 'render_stats_spy'));
    }

    function render_stats_spy () {

      // Prepare StatsSpy data object to be used by template
      $stats_spy_data = (object)[
        'total_orders_count' => 0,
        'completed_orders_count' => 0,
        'page_views' => 0,
        'sales' => 0,
        'seller_stats' => [],
        'formatted_sales' => 0
      ];

      // For each seller create a data object and update total values
      $user_search = new WP_User_Query( array( 'role' => 'seller', 'orderby' => 'display_name' ) );
      $sellers = (array) $user_search->get_results();
      foreach ($sellers as $seller) {
        $user_id = $seller->data->ID;

        $edit_link = esc_url( add_query_arg( 'wp_http_referer', urlencode( wp_unslash( $_SERVER['REQUEST_URI'] ) ), get_edit_user_link( $user_id ) ) );
        $store_settings = dokan_get_store_info( $user_id );
        $orders_counts = dokan_count_orders( $user_id );
        $sales = dokan_author_total_sales($user_id);

        $seller_stats = (object)[
          'edit_link' => $edit_link,
          'display_name' => $seller->data->display_name,
          'store_name' => $store_settings['store_name'],
          'total_orders_count' => $orders_counts->{'total'},
          'completed_orders_count' => $orders_counts->{'wc-completed'},
          'page_views' => (int) dokan_author_pageviews($user_id),
          'sales' => $sales,
          'formatted_sales' => woocommerce_price($sales)
        ];

        $stats_spy_data->total_orders_count += $seller_stats->total_orders_count;
        $stats_spy_data->completed_orders_count += $seller_stats->completed_orders_count;
        $stats_spy_data->page_views += $seller_stats->page_views;
        $stats_spy_data->sales += $seller_stats->sales;

        array_push($stats_spy_data->seller_stats, $seller_stats);
      }
      $stats_spy_data->formatted_sales = woocommerce_price($stats_spy_data->sales);


      set_query_var('1thirteen-stats-spy-data', $stats_spy_data );
      load_template( dirname( __FILE__ ) . '/templates/stats-spy.php' );
    }
  }

endif;

new OneThirteenStatsSpy();

?>