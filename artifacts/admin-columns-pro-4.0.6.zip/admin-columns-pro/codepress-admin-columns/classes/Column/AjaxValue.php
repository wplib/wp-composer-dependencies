<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface AC_Column_AjaxValue {

	/**
	 * @param int $id
	 *
	 * @return void
	 */
	public function get_ajax_value( $id );

}
