<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @see ACP_Column_Post_Date
 * @since 4.0
 */
class ACP_Column_Media_Date extends AC_Column_Media_Date {

}
