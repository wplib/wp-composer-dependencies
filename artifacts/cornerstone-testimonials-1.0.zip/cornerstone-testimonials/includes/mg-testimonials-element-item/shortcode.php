<?php

/**
 * Shortcode definition
 */

$class = 'mg-testimonials-item ' . $class;
?>

<li <?php echo cs_atts( array( 'id' => $id, 'class' => $class, 'style' => $style ) ); ?>>

	<div class="content_bg">
		<span class="qoute"><i class="x-icon x-icon-quote-left" data-x-icon="" aria-hidden="true"></i></span>
		<p><?php echo $content; ?></p>
	</div>
	<div class="img-container">
		<?php if( !empty( $src ) ) : ?>
			<img src="<?php echo $src; ?>" alt="" />
		<?php endif; ?>
	</div>
	<div class="identity-container">
		<span class="name">
			<?php echo $heading; ?>
		</span>
		<span class="designation">
			<?php echo $designation; ?>
		</span>
	</div>
</li>