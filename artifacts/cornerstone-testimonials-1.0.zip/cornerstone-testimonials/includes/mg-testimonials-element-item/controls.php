<?php

/**
 * Element Controls
 */

return array(
	'heading' => array(
		'type' => 'title',
		'context' => 'content',
		'suggest' => __('Enter Your Name', 'mg-testimonials')
	),
	'src' => array(
		'type' => 'image',
		'ui' => array(
			'title' => __('Image', 'mg-testimonials'),
			'tooltip' => __('Select your image.', 'mg-testimonials')
		),
		'context' => 'content',
		'suggest' => MG_TESTIMONIALS_URL . '/assets/image/no-profile-image.jpg'
	),
	'designation' => array(
		'type' => 'text',
		'ui' => array(
			'title' => __('Designation', 'mg-testimonials'),
			'tooltip' => __('Select Your Designation', 'mg-testimonials')
		),
		'suggest' => __('Designation', 'mg-testimonials')
	),
	'content' => array(
		'type' => 'editor',
		'ui' => array(
			'title' => __('Content', 'mg-testimonials'),
			'tooltip' => __('Testimonial Content', 'mg-testimonials')
		),
		'suggest' => __('Testimonial Content', 'mg-testimonials')
	)
);