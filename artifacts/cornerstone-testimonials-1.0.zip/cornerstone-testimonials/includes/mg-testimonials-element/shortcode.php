<?php

/**
 * Shortcode definition
 */
$class = "mg-testimonials mg-grid " . $class;
$class .= $type .' '. $layout ;
$id = 'mg_' . mt_rand();

if ($columns == "mg-three-col") {
	$item = '3';
	$item_tab = '2';
} elseif ($columns == 'mg-two-col') {
	$item = '2';
	$item_tab = '2';
} else{
	$item = '1';
	$item_tab = '1';
}
?>
<style>
	#<?php echo $id; ?>.mg-testimonials .content_bg{
		background-color: <?php echo $background; ?>;
	}
	#<?php echo $id; ?>.mg-style2 img{
		border-color: <?php echo $background; ?>;
	}
	#<?php echo $id; ?>.mg-style2 .content_bg:after{
		border-top-color: <?php echo $background; ?>;
	}
	#<?php echo $id; ?>.mg-style3 .identity-container{
		border-top-color: <?php echo $contcolor; ?>;
	}
	#<?php echo $id; ?> .content_bg p, #<?php echo $id; ?> span.qoute{
		color: <?php echo $contcolor; ?> !important;
	}
	#<?php echo $id; ?> .identity-container span{
		color: <?php echo $identitycolor; ?> !important;
	}
	#<?php echo $id; ?> .owl-nav .x-icon:before{
		color: <?php echo $navcolor; ?>;
	}
	#<?php echo $id; ?> .owl-theme .owl-controls .owl-nav div{
		background: <?php echo $navbgcolor; ?>;
	}
	#<?php echo $id; ?> .owl-theme .owl-controls .owl-dots span{
		background: <?php echo $navbgcolor; ?>;
		
	}
</style>

<?php if ( $type == 'testimonials-slider' ) : ?>
<script>
jQuery(function($){
	$( "#<?php echo $id; ?>.testimonials-slider .mg-testimonial-container").owlCarousel({
	    autoplay : <?php echo !empty( $autoplay ) ? 'true' : 'false'; ?>,
	    autoplayHoverPause : true,
		loop: true,
		autoplayTimeout: <?php echo $autoplay_time*1000; ?>,
	    autoplaySpeed : 600,
	    navSpeed : 600,
	    dotsSpeed: 600,
	    margin: 15,
	    nav : <?php echo !empty( $nav_button ) ? 'true' : 'false'; ?>,
	    navText: [
	      '<i class="x-icon x-icon-chevron-left" data-x-icon="" aria-hidden="true"></i>',
	      '<i class="x-icon x-icon-chevron-right" data-x-icon="" aria-hidden="true"></i>'
	      ],
	    dots: <?php echo !empty( $slider_dots ) ? 'true' : 'false'; ?>,
	    responsiveClass:true,
	    responsive:{
	        0:{
	            items:1,
	        },
	        600:{
	            items:<?php echo $item_tab ?>,
	        },
	        1000:{
	        	items:<?php echo $item ?>,
	        }
	    }
	});
});
</script>
<?php endif; ?>

<div <?php echo cs_atts( array( 'id' => $id, 'class' => $class, 'style' => $style ) ); ?>>
	<ul class="mg-testimonial-container <?php echo $columns ;?>">
		<?php  echo do_shortcode( $content ); ?>
	</ul>	
</div>