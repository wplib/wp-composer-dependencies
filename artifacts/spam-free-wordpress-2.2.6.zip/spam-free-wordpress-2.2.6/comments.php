<?php

	show_comment_form();

	function show_comment_form() {
		global $sfwform;

		$sfwform->sfw_comment_form_header();
	}
