<?php

/*
* Legacy function for versions prior to 1.7.8
*/
function tl_spam_free_wordpress_comments_form() {
	sfw_comment_form_extra_fields();
}
