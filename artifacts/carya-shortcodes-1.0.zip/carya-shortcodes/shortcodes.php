<?php
/*
Plugin Name: Carya Shortcodes
Plugin URI: http://gomalthemes.com/
Description: Carya shortcodes provides a free set of different shortcodes for your wordpress theme!
Version: 1.0
Author: Gomal Themes
Author URI: http://gomalthemes.com/
License: GPLv2
*/
// Row Shortcode
function row_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['row_id'])){
        $row_id = $atts['row_id'];
    } else {
        $row_id = "no-id";
    }
    $out = '';
    $out .= '<div class="row" id="' . $row_id . '" >' . do_shortcode($content) .'</div>';
    return $out;
}
add_shortcode('row', 'row_shortcode');
// Column Shortcode
function column_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if($atts['col_class'] == "xs"){
        $class = "col-xs-";
    } elseif($atts['col_class'] == "sm") {
        $class = "col-sm-";
    } elseif($atts['col_class'] == "md") {
        $class = "col-md-";
    } elseif($atts['col_class'] == "lg") {
        $class = "col-lg-";
    } else {
        $class = "col-sm-";
    }

    $out = '';
    $out .= '<div class="' . $class.$atts['size'] . '" >' . do_shortcode($content) .'</div>';
    return $out;
}
add_shortcode('column', 'column_shortcode');
// Title Shortcode
function title_shortcode( $atts) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['title_text'])){
        $title_text = $atts['title_text'];
    } else {
        $title_text = "Add your title text in Shortcode";
    }
    if(!empty($atts['title_type'])){
        $title_type = $atts['title_type'];
    } else {
        $title_type = "type1";
    }
    if($title_type == "type1" ){
        $title_type = '<div class="section-title"><h2>'. $title_text .'</h2></div>';
    } else {
        $title_type = '<h1 class="category-title text-capitalize">'. $title_text .'</h1>';
    }
    $out = '';
    $out .= $title_type;
    return $out;
}
add_shortcode('title', 'title_shortcode');
// Social Shortcode
function social_shortcode( $atts) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['link_type'])){
        $link = $atts['link_type'];
    } else {
        $link = 'target="_blank"';
    }
    if($link == "yes"){
        $link = 'target="_blank"';
    }else {
        $link = '';
    }

    if(!empty($atts['facebook'])){
        $facebook = '<a href="'.$atts['facebook'].'" class="fa fa-facebook" '.$link.'></a>';
    } else{
        $facebook = '';
    }
    if(!empty($atts['dribble'])){
        $dribble = '<a href="'.$atts['dribble'].'" class="fa fa-dribbble" '.$link.'></a>';
    } else{
        $dribble = '';
    }
    if(!empty($atts['twitter'])){
        $twitter = '<a href="'.$atts['twitter'].'" class="fa fa-twitter" '.$link.'></a>';
    } else{
        $twitter = '';
    }
    if(!empty($atts['tumbler'])){
        $tumbler = '<a href="'.$atts['tumbler'].'" class="fa fa-tumblr" '.$link.'></a>';
    } else{
        $tumbler = '';
    }
    if(!empty($atts['behance'])){
        $behance = '<a href="'.$atts['behance'].'" class="fa fa-behance" '.$link.'></a>';
    } else{
        $behance = '';
    }
    if(!empty($atts['vine'])){
        $vine = '<a href="'.$atts['vine'].'" class="fa fa-vine" '.$link.'></a>';
    } else{
        $vine = '';
    }
    if(!empty($atts['linkedin'])){
        $linkedin = '<a href="'.$atts['linkedin'].'" class="fa fa-linkedin" '.$link.'></a>';
    } else{
        $linkedin = '';
    }
    if(!empty($atts['youtube'])){
        $youtube = '<a href="'.$atts['youtube'].'" class="fa fa-youtube" '.$link.'></a>';
    } else{
        $youtube = '';
    }
    if(!empty($atts['google'])){
        $google = '<a href="'.$atts['google'].'" class="fa fa-google-plus" '.$link.'></a>';
    } else{
        $google = '';
    }
    if(!empty($atts['icon_version'])){
        $version = $atts['icon_version'];
    } else {
        $version = 'dark';
    }
    if($version == "light"){
        $version = "light";
    }else {
        $version = "dark";
    }

    $out = '';
    $out .= '<div class="socials '.$version.'">';
    $out .= $facebook;
    $out .= $twitter;
    $out .= $linkedin;
    $out .= $youtube;
    $out .= $google;
    $out .= $dribble;
    $out .= $tumbler;
    $out .= $behance;
    $out .= $vine;
    $out .= '</div>';
    return $out;
}
add_shortcode('social', 'social_shortcode');
// Button Shortcode
function button_shortcode( $atts) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['button_text'])) {
        $text = $atts['button_text'];
    } else {
        $text = "Read More";
    }
    if(!empty($atts['button_style'])){
        $class = $atts['button_style'];
    } else {
        $class = '';
    }
    if(!empty($atts['button_link'])){
        $link = $atts['button_link'];
    } else {
        $link = "#";
    }
    $out = '';
    $out .= '<a href="'.$link.'" class="btn btn-outline read-more '. $class .'">'. $text .'</a>';
    return $out;
}
add_shortcode('button', 'button_shortcode');
// Flex Slider Shortcode
function flex_shortcode( $atts, $content = null) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<div id="slider" class="slider fit">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    return $out;
}
add_shortcode('slides', 'flex_shortcode');
// Tabs Shortcode
add_shortcode('tabs', 'shortcode_tabs');
function shortcode_tabs( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));

    $out = '';
    $out .= '<ul class="nav nav-tabs" role="tablist">';
    $i = 1;
    foreach ($atts as $key => $tab) {
        if($i == 1) {
            $out .= '<li role="presentation" class="active"><a href="#' . $key . '" aria-controls="'. $key .'" role="tab" data-toggle="tab">' . $tab . '</a></li>';
        } else {
            $out .= '<li role="presentation"><a href="#' . $key . '" aria-controls="'. $key .'" role="tab" data-toggle="tab">' . $tab . '</a></li>';
        }
        $i++;
    }
    $out .= '</ul>';
    $out .= '<div class="tab-content">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    return $out;
}
add_shortcode('tab', 'shortcode_tab');
function shortcode_tab( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<div role="tabpanel" class="tab-pane fade" id="tab' . $atts['id'] . '" >' . do_shortcode($content) .'</div>';
    return $out;
}
// List Style Shortcode
function lists_shortcode( $atts, $content = null) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<ul class="link-list">';
    $out .= do_shortcode($content);
    $out .= '</ul>';
    return $out;
}
add_shortcode('lists', 'lists_shortcode');
function list_shortcode( $atts, $content = null) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<li>';
    $out .= do_shortcode($content);
    $out .= '</li>';
    return $out;
}
add_shortcode('list', 'list_shortcode');
// Advertisement Shortcode
function ad_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['ad_img'])){
        $img = $atts['ad_img'];
    } else {
        $img = "http://placehold.it/1200x200&text=No+Image+Preview";
    }
    if(!empty($atts['ad_link'])){
        $link = $atts['ad_link'];
    } else {
        $link = "#";
    }
    $out = '';
    $out .= '<a href="'. $link .'"><img src="'.$img.'" alt="Advertisment" class="advertisment"></a>';
    return $out;
}
add_shortcode('ad', 'ad_shortcode');
// Youtube Shortcode
function youtube_shortcode( $atts ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['url'])){
        $url = $atts['url'];
    } else {
        $url = '';
    }
    if(!empty($atts['width'])){
        $width = $atts['width'];
    } else {
        $width = "100%";
    }
    if(!empty($atts['height'])){
        $height = $atts['height'];
    } else {
        $height = "300";
    }
    $out = '';
    $out .= '<iframe width="'.$width.'" height="'. $height .'" src="'. $url .'"></iframe>';
    return $out;
}
add_shortcode('youtube', 'youtube_shortcode');
// Vimeo Shortcode
function vimeo_shortcode( $atts ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['id'])){
        $id = $atts['id'];
    } else {
        $id = '';
    }
    if(!empty($atts['width'])){
        $width = $atts['width'];
    } else {
        $width = "100%";
    }
    if(!empty($atts['height'])){
        $height = $atts['height'];
    } else {
        $height = "300";
    }
    $out = '';
    $out .= '<iframe src="http://player.vimeo.com/video/'.$id.'" width="'.$width.'" height="'.$height.'" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
    return $out;
}
add_shortcode('vimeo', 'vimeo_shortcode');
// Soundcloud Shortcode
function soundcloud_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= do_shortcode($content);
    return $out;
}
add_shortcode('soundcloud', 'soundcloud_shortcode');